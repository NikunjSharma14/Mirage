// Search functionality
document.getElementById('searchForm')?.addEventListener('submit', async (e) => {
    e.preventDefault();
    const query = document.getElementById('searchQuery').value;
    
    try {
        const response = await fetch(`/search?q=${encodeURIComponent(query)}`);
        const results = await response.json();
        displayResults(results);
    } catch (error) {
        console.error('Search failed:', error);
    }
});

// Upload functionality
document.getElementById('uploadForm')?.addEventListener('submit', async (e) => {
    e.preventDefault();
    
    const formData = new FormData();
    formData.append('title', document.getElementById('title').value);
    formData.append('author', document.getElementById('author').value);
    formData.append('abstract', document.getElementById('abstract').value);
    formData.append('file', document.getElementById('file').files[0]);

    try {
        const response = await fetch('/upload', {
            method: 'POST',
            body: formData
        });
        
        if (response.ok) {
            alert('Paper uploaded successfully!');
            window.location.href = '/';
        } else {
            alert('Upload failed. Please try again.');
        }
    } catch (error) {
        console.error('Upload error:', error);
        alert('An error occurred during upload.');
    }
});

// Display search results
function displayResults(results) {
    const resultsDiv = document.getElementById('searchResults');
    resultsDiv.innerHTML = '';

    if (results.length === 0) {
        resultsDiv.innerHTML = '<p>No papers found matching your search.</p>';
        return;
    }

    results.forEach(result => {
        const paperDiv = document.createElement('div');
        paperDiv.className = 'paper-card';
        paperDiv.innerHTML = `
            <h3>${result.title}</h3>
            <p class="author">By ${result.author}</p>
            <p class="abstract">${result.abstract}</p>
            <div class="actions">
                <a href="/uploads/${result.filePath.split('/').pop()}" download 
                   class="download-btn">Download PDF</a>
            </div>
        `;
        resultsDiv.appendChild(paperDiv);
    });
}