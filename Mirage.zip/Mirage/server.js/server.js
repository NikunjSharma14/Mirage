const express = require('express');
const multer = require('multer');
const mongoose = require('mongoose');
const path = require('path');
const fs = require('fs');

const app = express();
const port = process.env.PORT || 3000;

// Database connection
mongoose.connect('mongodb://127.0.0.1:27017/mirage', {
    useNewUrlParser: true,
    useUnifiedTopology: true
});

// Research model
const researchSchema = new mongoose.Schema({
    title: String,
    author: String,
    abstract: String,
    filePath: String,
    uploadDate: { type: Date, default: Date.now }
});

const Research = mongoose.model('Research', researchSchema);

// File upload configuration
const storage = multer.diskStorage({
    destination: (req, file, cb) => {
        const uploadDir = path.join(__dirname, 'uploads');
        if (!fs.existsSync(uploadDir)) {
            fs.mkdirSync(uploadDir, { recursive: true });
        }
        cb(null, uploadDir);
    },
    filename: (req, file, cb) => {
        cb(null, Date.now() + '-' + file.originalname);
    }
});

const upload = multer({ storage });

// Middleware
app.use(express.static('public'));
app.use(express.urlencoded({ extended: true }));
app.use('/uploads', express.static('uploads'));

// Routes
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

app.get('/upload', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'upload.html'));
});

app.post('/upload', upload.single('file'), async (req, res) => {
    try {
        const { title, author, abstract } = req.body;
        const newResearch = new Research({
            title,
            author,
            abstract,
            filePath: req.file.path
        });
        
        await newResearch.save();
        res.status(200).send();
    } catch (error) {
        console.error('Upload error:', error);
        res.status(500).send('Server error');
    }
});

app.get('/search', async (req, res) => {
    try {
        const query = req.query.q;
        const results = await Research.find({
            $or: [
                { title: { $regex: query, $options: 'i' } },
                { author: { $regex: query, $options: 'i' } },
                { abstract: { $regex: query, $options: 'i' } }
            ]
        }).sort({ uploadDate: -1 });

        res.json(results);
    } catch (error) {
        console.error('Search error:', error);
        res.status(500).json({ error: 'Server error' });
    }
});

// Start server
app.listen(port, () => {
    console.log(`Server running on http://localhost:${port}`);
});